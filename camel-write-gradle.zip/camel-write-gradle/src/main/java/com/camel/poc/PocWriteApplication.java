package com.camel.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocWriteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocWriteApplication.class, args);
	}

}
